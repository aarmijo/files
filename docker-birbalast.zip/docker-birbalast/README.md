# Docker

# Modify

In "docker" folder generate "daemon.json" file:

    {
        "bip": "192.168.109.1/24"
    }


# Node-RED

## Usage

Start the image as follows:
    
    docker-compose up

Linux, Start the image as follows :

    sudo systemctl start docker
    sudo docker-compose up

Rebuild the image:

    docker-compose build

## Create custom nodes
In "images/custom-nodes" folder there are two folders:
*  node-apps: This folder contains node projects used for testing the 
functionalities of the custom node
*  node-red-contrib-fft-js: This folder contains a custom node.
*  node-red-contrib-smawjson-smawinflux: This folder contains a custom node to parse a JSON smaw structure to smaw InfluxDB structure
Follow the instructions on [Creating your first node](https://nodered.org/docs/creating-nodes/first-node)
to create a new node. More custom nodes can be added next to this folder.
To install a new custom node, add the next lines to the file /images/Dockerfile:
    
    # Copy custom node node-red-contrib-fft-js
    COPY custom-nodes/node-red-contrib-fft-js ./node-red-contrib-fft-js
    RUN npm install node-red-contrib-fft-js


## References
- http://www.steves-internet-guide.com/working-with-json-data-node-red/
- https://www.toptal.com/nodejs/programming-visually-with-node-red
- https://nodered.org/docs/creating-nodes/first-node