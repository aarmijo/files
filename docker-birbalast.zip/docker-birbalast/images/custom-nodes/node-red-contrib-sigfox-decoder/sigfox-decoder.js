module.exports = function(RED) {
    function decode(config) {
        RED.nodes.createNode(this,config);
        var node = this;
        node.on('input', function(msg) {
            
            var SiguinoFields = {
                SEQ_NUM: [0, 8],
                TEMPERATURE: [8, 15],
                LIGHT_AVG: [15, 25],
                SHOCK_OCCURRED: [25, 26],
                MAG_OCCURRED: [26, 27],
                BATT_LVL: [27, 31],
                PRESSURE: [31, 39],
                HUMIDITY: [39, 46],
                ALTITUDE: [46, 55]
            };

            function reverse_string(s) {
                return s.split("").reverse().join("");
            }

            function hex2bin(hex_val) {
              var returnValue = ''; // Empty string to add our data to later on.

              for (var i = 0; i < parseInt(hex_val.length / 2); i++) {
                // Determining the substring.
                var substring = hex_val.substr(i * 2, 2);
                // Determining the binValue of this hex substring.
                var binValue = parseInt(substring, 16).toString(2);

                // If the length of the binary value is not equal to 8 we add leading 0s (js deletes the leading 0s)
                // For instance the binary number 00011110 is equal to the hex number 1e,
                // but simply running the code above will return 11110. So we have to add the leading 0s back.
                if (binValue.length != 8) {
                  // Determining how many 0s to add:
                  var diffrence = 8 - binValue.length;

                  // Adding the 0s:
                  for (var j = 0; j < diffrence; j++) {
                    binValue = '0' + binValue;
                  }
                }

                // Adding the binValue to the end string which we will return.
                returnValue += binValue;
              }
              // Returning the decompressed string.
              return returnValue;
            }

            function get_siguino_value(siguino_data, field_name) {
              if ((siguino_data.length % 2) == 1) siguino_data = "0" + siguino_data;
              var binary_data = hex2bin(siguino_data);
              var reversed = reverse_string(binary_data);
              var binary_value = reverse_string(reversed.slice(SiguinoFields[field_name][0], SiguinoFields[field_name][1]));
              //console.log(binary_value);
              var result = parseInt(binary_value, 2);
              if (field_name == "TEMPERATURE") {
                result /= 2;
              }
              return result;
            }

            let sigfoxData = msg.payload.data.temp;
            let seq = get_siguino_value(sigfoxData, "SEQ_NUM");
            let temp = get_siguino_value(sigfoxData, "TEMPERATURE");
            let light = get_siguino_value(sigfoxData, "LIGHT_AVG");
            let shockOccurred = get_siguino_value(sigfoxData, "SHOCK_OCCURRED");
            let mag = get_siguino_value(sigfoxData, "MAG_OCCURRED");
            let batt = get_siguino_value(sigfoxData, "BATT_LVL");
            let pressure = get_siguino_value(sigfoxData, "PRESSURE");
            let humidity = get_siguino_value(sigfoxData, "HUMIDITY");
            let altitude = get_siguino_value(sigfoxData, "ALTITUDE");
		
            let decodedData = {seq: seq, temp: temp, light: light, shockOccurred: shockOccurred, mag: mag, batt: batt, pressure: pressure, humidity: humidity, altitude: altitude};
            
            msg.payload = {data: {device: msg.payload.data.device, temp: sigfoxData, decodedData: decodedData}};
            node.send(msg);
        });
    }
    RED.nodes.registerType("sigfox decoder",decode);
}
