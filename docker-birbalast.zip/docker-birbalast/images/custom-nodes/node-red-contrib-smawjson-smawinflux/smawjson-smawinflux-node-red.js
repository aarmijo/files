module.exports = function(RED) { 
        function smawJsonToInflux(config) { 
		RED.nodes.createNode(this,config); 
		var node = this; 
		node.on('input', function(msg) {
			var outputMsgs = [];
			var nodeLength = msg.payload.nodes.length;
			for (var i = 0; i < nodeLength; i++) {
    				var data=msg.payload.nodes[i].data;
    				//var node=msg.payload.nodes[i].id_node;
    				for(var j =0; j <data.length;j++){
        				for (var field in data[j].fields) {
           
            					var point=
            					[{
               						time: new Date(data[j].time *1000),
                					log_value: data[j].fields[field],
                					log_date_registered: data[j].time *1000
             					 },
            					 { 
                					log_node_id: msg.payload.nodes[i].id_node,
                					log_value_description: field,
                					log_location: msg.payload.location, 
            					 }  
            					];
            					outputMsgs.push(point);
        				}
    				}
			}
			msg.payload=outputMsgs;
  			node.send(msg); 
        	});
    	}
    	RED.nodes.registerType("smawjsontoinfluxdb",smawJsonToInflux);
}
