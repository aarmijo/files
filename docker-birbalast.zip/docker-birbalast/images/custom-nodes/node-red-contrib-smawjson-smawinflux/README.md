# Docker

# Node-RED contribution smawjson to smaw influxdb

Transforms a smaw JSON structure to a smaw InfluxDB structure

## Example of smaw JSON structure

``` { 
    "location" : "xxxxxx", 
    "nodes" : [ {  
        "id_node" : "1001", 
        "data" : [{ 
            "time" : "1522914845", 
            "fields":{         
                "c": 0, 
				"d": 0, 
				"e": 395365, 
				"pw": 0, 
				"pwf": 1000, 
				"r": true, 
				"t": 0, 
				"v": 224047 
            } 
        }] 
    }, 
    {  
        "id_node" : "1002", 
        "data" : [{ 
           "time" : " 1522914845", 
           "fields":{         
                "c": 0, 
				"d": 0, 
				"e": 395350, 
				"pw": 0, 
				"pwf": 1000, 
				"r": true, 
				"t": 0, 
				"v": 224047 
            } 
        }] 
    }, 
    …..............       
    ] 
}
```

## Example of smaw JSON structure

 ```[ 
    {     
        time: 1522914845000  //Date in ms 
        log_date_registered: 1522914845000  //Integer 
        log_value: 0 
	}, 
	{ 
		log_node_id =”1001”  //de momento el id del equipo             
		log_value_description: “c” 
		log_location:” Gateway 1” 
	} 
], 
[ 
    {     
        time: 1522914845000 
        log_date_registered: 1522914845000 
        log_value: 0 
	}, 
	{ 
		log_node_id=”1001” 
		log_value_description: “d” 
		log_location:” Gateway 1” 
	} 
], 
…… 
… 
[ 
    {     
        time: 1522914845000 
        log_date_registered: 1522914845000 
        log_ value: 0 
	}, 
	{ 
		log_node_id=”1002” 
		log_value_description: “c” 
		log_location:” Gateway 1” 
	} 
]```