// FFT calculation
// Aliasing: sampleRate/2
// Delta frequency: sampleRate / signal.length

var fft = require('fft-js').fft,
    fftutil = require('fft-js').util,
    signal = [1,1,1,1,0,0,0,0],
    sampleRate = 44100;

console.log('Signal: ', signal);

var complexCoef = fft(signal); //This includes coefficients for the negative frequencies, and the Nyquist frequency.
console.log('FFT: ', complexCoef);

var magnitudes = fftutil.fftMag(complexCoef);
console.log('FFT Magnitudes: ', magnitudes);

var frequencies = fftutil.fftFreq(complexCoef, sampleRate);
console.log('FFT Frequencies: ', frequencies);

// fundamental
var maxMagnitude = Math.max(...magnitudes);
var indexOfMaxMagnitude = magnitudes.indexOf(maxMagnitude);
var maxMagnitudeFrequency = frequencies[indexOfMaxMagnitude];
console.log(`1 - Fundamental Frequency: ${maxMagnitudeFrequency} Hz`);
console.log('1 - Fundamental Frequency Magnitude: ', maxMagnitude);

// spur
magnitudes.splice(indexOfMaxMagnitude, 1);
frequencies.splice(indexOfMaxMagnitude,1);
console.log('FFT remaining Magnitudes: ', magnitudes);
console.log('FFT remaining Frequencies: ', frequencies);
maxMagnitude = Math.max(...magnitudes);
indexOfMaxMagnitude = magnitudes.indexOf(maxMagnitude);
maxMagnitudeFrequency = frequencies[indexOfMaxMagnitude];
console.log(`2 - Spur Frequency: ${maxMagnitudeFrequency} Hz`);
console.log('2 - Spur Frequency Magnitude: ', maxMagnitude);
