var fft = require('fft-js').fft,
    fftutil = require('fft-js').util

module.exports = function(RED) {
    function calculateFFT(config) {
        RED.nodes.createNode(this,config);
        this.samplingFrequency = config.samplingFrequency;
        var node = this;
        node.on('input', function(msg) {
            var signal = msg.payload;
            var complexCoef = fft(signal);         
            var magnitudes = fftutil.fftMag(complexCoef);			
			var frequencies = fftutil.fftFreq(complexCoef, node.samplingFrequency);			
            msg.payload = {frequencies, magnitudes};
            node.send(msg);
        });
    }
    RED.nodes.registerType("fft",calculateFFT);
}
